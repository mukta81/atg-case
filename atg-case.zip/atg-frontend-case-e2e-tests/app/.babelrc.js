module.exports = {
  presets: [["react-app", { flow: false, typescript: true }]],
};
