export async function fetchTrackData(betType: string) {
  const BASE_URL = `https://www.atg.se/services/racinginfo/v1/api/products`;

  try {
    const response = await fetch(`${BASE_URL}/${betType}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch data for bet type: ${betType}`);
    }
    const data = await response.json();
    const trackNameDate: { name: string; startTime: string; id: string }[] = []; 

    data.results.forEach((result) => {
      const trackNames = result.tracks.map((track) => track.name).join(" & ");
      trackNameDate.push({
        name: trackNames,
        startTime: result.startTime,
        id: result.id,
      });
    });

    console.log('Fetched Data:', betType, trackNameDate); 
    return trackNameDate;
  } catch (error) {
    console.error("Error fetching track data:", error);
    throw error;
  }
}

export async function fetchRaceData(betType: string, type:string) {
  const BASE_URL = `https://www.atg.se/services/racinginfo/v1/api/games`;
//console.log("inside-----------", betType)
  const resultIDNameDate = await fetchTrackData(betType)
  const trackId = resultIDNameDate[0]?.id;
 // console.log("trackId....."+trackId)
  try {
    const response = await fetch(`${BASE_URL}/${trackId}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch data for bet type: ${betType}`);
    }
    const data = await response.json();
    const raceDetails = data.races[0];  //first record
    const formattedTime = new Date(raceDetails.startTime).toLocaleTimeString([], {
      hour: 'numeric',
      minute: 'numeric',
      hour12: true
    });

    // Format the complete race data as a string
    const formattedRaceData = `${raceDetails.number}, ${raceDetails.name || ""}, ${formattedTime}`;

  //const startNumber = raceDetails.starts[0].number;
  const horseName = raceDetails.starts[0].horse.name;
  const driverFirstName = raceDetails.starts[0].driver.firstName;
  const driverLastName = raceDetails.starts[0].driver.lastName;
  const trainerFirstName = raceDetails.starts[0].horse.trainer.firstName
  const trainerLastName = raceDetails.starts[0].horse.trainer.lastName
  const horseFather = raceDetails.starts[0].horse.pedigree.father.name

    const formattedHorseDate = `${horseName}, ${driverFirstName}, ${driverLastName}, ${trainerFirstName}, ${trainerLastName}, ${horseFather}`;
    console.log('Formatted Race Data:......', formattedRaceData);
    
    if(type==="race")
    return formattedRaceData;
    else if(type==="horse")
      return formattedHorseDate;




  } catch (error) {
    console.error("Error fetching race data:", error);
    throw error;
  }
}