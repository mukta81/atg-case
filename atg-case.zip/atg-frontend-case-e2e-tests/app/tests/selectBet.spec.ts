import { test, expect } from "@playwright/test";
import { fetchTrackData , fetchRaceData} from '../utils/utils.ts'


const betTypes = ['V75', 'V86', 'GS75'];
const id: string='';
betTypes.forEach((betType) => {
  test(`001 to check ${betType} added before track name(s), start time`, async ({ page }) => {
    await page.goto("http://localhost:8080/");

    //let trackNameDate = await fetchTrackData(betType); 
  
    const dropdown = page.locator('.css-1qewwhh');
    await dropdown.nth(0).selectOption({ value: betType }); 

    await page.waitForSelector('h1'); 
    const h1Heading = page.locator("h1");

    const h1Count = await h1Heading.count();

    //check that bet type is dispayed correctly when a value in dropdown is selected
    for(let i=0; i<h1Count; i++){
      const labelText = await h1Heading.nth(i).innerText();
      expect(labelText).toContain(betType)
    }
  });
  });


betTypes.forEach((betType) => {
  test(`002 Select bet type ${betType} fetches correct data: most recent first`, async ({ page }) => {
    await page.goto("http://localhost:8080/");

    let trackNameDate = await fetchTrackData(betType); 
  
    const dropdown = page.locator('.css-1qewwhh');

    await dropdown.nth(0).selectOption({ value: betType }); 

    await page.waitForSelector('h1'); 
    const h1Heading = page.locator("h1");

    const h1Count = await h1Heading.count();

    let extractedDates: Date[] = []; 

    for(let i=0; i<h1Count; i++){
      const labelText = await h1Heading.nth(i).innerText();

      const track=trackNameDate[i];
      const id=track.id[0];
      const expectedName = track.name;
      const expectedStartTime = track.startTime; 

      const parts = labelText.split(' - ');
          
      let labelBetType: string | undefined=undefined;
      let labelTrackName: string='';
      let labelDateTime: string='';
      if (parts.length === 3) {
        [labelBetType, labelTrackName, labelDateTime] = parts;
        expect(labelBetType).toBe(betType); 
      } else if (parts.length === 2) {
        [labelTrackName, labelDateTime] = parts;
      }
     
     const labelDate = new Date(labelDateTime);
     extractedDates.push(labelDate);

      const formattedLabelDateTime = labelDate.toISOString().slice(0,16);

      const expectedDate = new Date(expectedStartTime);
      const formattedExpectedStartTime = expectedDate.toISOString().slice(0,16);
      
      
      expect(labelTrackName).toBe(expectedName);
      expect(formattedLabelDateTime).toBe(formattedExpectedStartTime);
    
    }

    for (let i = 1; i < extractedDates.length; i++) {
      expect(extractedDates[i - 1].getTime()).toBeGreaterThan(extractedDates[i].getTime());
    }



  });
  });


  betTypes.forEach((betType) => {
    test(`003 to check "Display order :oldest first working for ${betType}"`, async ({ page }) => {
      await page.goto("http://localhost:8080/");
  
      //let trackNameDate = await fetchTrackData(betType); 
    
      const dropdown = page.locator('.css-1qewwhh');
      await dropdown.nth(0).selectOption({ value: betType }); 
  
      await page.waitForSelector('h1'); 
      const h1Heading = page.locator("h1");
  
      const h1Count = await h1Heading.count();
      let descendingDates: Date[] = [];
      
      for(let i=0; i<h1Count; i++){
        const labelText = await h1Heading.nth(i).innerText();
      //  console.log("labelText-----"+labelText)
       // expect(labelText).toContain(betType)
       const parts = labelText.split(' - ');
      const labelDateTime = parts[parts.length - 1]; // Date is the last part
       descendingDates.push(new Date(labelDateTime));
      }


      await dropdown.nth(1).selectOption({ value: "1" });
      await page.waitForSelector('h1'); 
      const h1HeadingDisplay = page.locator("h1");
  
      const h1CountDisplay = await h1HeadingDisplay.count();
      const ascendingDates: Date[] = [];

      //check that bet type is dispayed correctly when a value in dropdown is selected
      for(let i=0; i<h1CountDisplay; i++){
        const labelTextDisplay = await h1HeadingDisplay.nth(i).innerText();
     //   console.log("labelTextDisplay====="+labelTextDisplay)
        const parts = labelTextDisplay.split(' - ');
      const labelDateTime = parts[parts.length - 1];
      ascendingDates.push(new Date(labelDateTime));
      }
      for (let i = 1; i < ascendingDates.length; i++) {
        expect(ascendingDates[i - 1].getTime()).toBeLessThanOrEqual(ascendingDates[i].getTime());
      }
      
    });
    });
  


    betTypes.forEach((betType) => {
      test(`004 to check information of selected bet type’s race for ${betType}"`, async ({ page }) => {
        await page.goto("http://localhost:8080/");
    
        let trackNameDate = await fetchRaceData(betType, "race"); 
      //console.log("trackNameDate............"+trackNameDate)
        const dropdown = page.locator('.css-1qewwhh');
        await dropdown.nth(0).selectOption({ value: betType }); 
    
        await page.waitForSelector('h2'); 
        const h2Heading = page.locator("h2").first();  //read first data
    
        const h2Count = await h2Heading.count();
        //console.log(h2Count+"=====..........count of h2")
        
        for(let i=0; i<h2Count; i++){
          const labelText = await h2Heading.nth(i).innerText();
         // console.log("label...........", labelText)
          const parts = labelText.split(' - ');

          const raceStartTime = parts.pop()?.trim() || "";
          const raceNumber = parts.shift()?.trim() || "";
          const raceName = parts.join(" - ").trim();

          //console.log("all 3--.............-"+raceNumber+", "+ raceName+", "+  raceStartTime)
          const opString = raceNumber+", "+ raceName+", "+  raceStartTime;
          //console.log(opString)


          expect(trackNameDate.toUpperCase()).toBe(opString.toUpperCase())
        }
      });
      });
    

      betTypes.forEach((betType) => {
        test(`005 to check information of a horse for ${betType}"`, async ({ page }) => {
          await page.goto("http://localhost:8080/");
      
          let horseInfo = await fetchRaceData(betType, "horse"); 
          //console.log("horseInfo............"+horseInfo)
          const dropdown = page.locator('.css-1qewwhh');
          await dropdown.nth(0).selectOption({ value: betType }); 
          
          //await page.waitForSelector("//details[@class='css-1pmdnv4']/summary"); 

          // const startingHorseInfo = page.locator("//details[@class='css-1pmdnv4']/summary").first();
          // const horseText = await startingHorseInfo.innerText();
          // console.log("horseText...........", horseText)
       
          const detailsFar = page.locator('.css-1pmdnv4').first()
          await detailsFar.click();
          const detailedFarText = await detailsFar.innerText();
          //console.log("detailedText...........", detailedFarText)

          const [horseName, driverFirstName, driverLastName, trainerFirstName, trainerLastName, fatherName] = horseInfo.split(", ").map(part => part.trim());
          //console.log(horseName, driverFirstName, driverLastName, trainerFirstName, trainerLastName, fatherName+"...............") 
          expect(detailedFarText).toContain(horseName); 
          expect(detailedFarText).toContain(driverFirstName);  
          expect(detailedFarText).toContain(driverLastName); 
          expect(detailedFarText).toContain("Tränare:\n" + trainerFirstName + " " + trainerLastName);  // Check the trainer section
          expect(detailedFarText).toContain("Far:\n" + fatherName); 

          
        });
        });