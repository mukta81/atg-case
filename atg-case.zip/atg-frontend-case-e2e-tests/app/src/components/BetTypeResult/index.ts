export { BetTypeResult } from "./BetTypeResult";
