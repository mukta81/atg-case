import styled from "@emotion/styled";

export const GameContainer = styled.div`
  & > div + div {
    margin-top: 16px;
  }
`;
