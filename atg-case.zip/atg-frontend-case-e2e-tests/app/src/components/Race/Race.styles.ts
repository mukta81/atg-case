import styled from "@emotion/styled";

export const RaceBorder = styled.div`
  border: 1px solid rgba(0, 0, 0, 0.26);
`;

export const RaceContainer = styled.div`
  padding: 8px;
`;
