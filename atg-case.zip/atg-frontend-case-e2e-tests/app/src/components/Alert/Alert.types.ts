export enum Severity {
  WARNING = "warning",
  ERROR = "error",
}
