import styled from "@emotion/styled";

export const Select = styled.select`
  padding: 4px 8px;
  cursor: pointer;
`;
